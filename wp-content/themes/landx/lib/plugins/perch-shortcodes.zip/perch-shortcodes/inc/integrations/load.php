<?php

/**
 * Class for managing integrations with other plugins
 */
class Tp_Integrations {

}